def run():
    print("Shrimptastic")
